﻿# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

### Change Execution Policy
Set-ExecutionPolicy -ExecutionPolicy Unrestricted

### Install Required Modules
Install-Module Az -AllowClobber -Force 
