﻿-- Copyright (c) Microsoft Corporation.
-- Licensed under the MIT License.

CREATE SCHEMA [External]
	AUTHORIZATION [dbo];